
import javax.servlet.http.*;
public class SampleTraversal extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response) {
        String p = request.getHeader("X-File");
        java.io.FileOutputStream fos = null;
        try {
            String path = "/srv/files/" + p;
            fos = new java.io.FileOutputStream(path, false);
        } catch (Exception e) { }
    }
}
