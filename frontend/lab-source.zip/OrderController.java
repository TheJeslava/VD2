package x;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/orders")
public class OrderController {
  private JdbcTemplate jdbc;
  @PostMapping("/create")
  public void create(@RequestParam String name) {
    jdbc.update("INSERT INTO orders(name) VALUES ('" + name + "')");
  }
  @GetMapping("/search")
  public Object search() {
    String stored = jdbc.queryForObject("SELECT name FROM orders WHERE id=1", String.class);
    return jdbc.queryForList("SELECT * FROM orders WHERE name='" + stored + "'");
  }
}
